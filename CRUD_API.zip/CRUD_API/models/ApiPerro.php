<?php
require_once 'conexion.php';

class ApiPerro extends Conexion {
    
    // Guardar raza de perro
    public static function guardar($raza, $imagen_url, $es_favorito = 0) {
        try {
            // Obtener fecha actual
            $fecha_actual = date('Y-m-d H:i:s');
            
            $sql = "INSERT INTO api_perros (per_raza, per_imagen_url, per_es_favorito, per_fecha_guardado)
                    VALUES (?, ?, ?, ?)";
            $stmt = self::conectar()->prepare($sql);
            $stmt->execute([$raza, $imagen_url, $es_favorito, $fecha_actual]);
            
            return ['success' => true, 'message' => 'Raza guardada correctamente'];
            
        } catch (PDOException $e) {
            error_log('Error al guardar raza: ' . $e->getMessage());
            return ['success' => false, 'message' => 'Error al guardar raza: ' . $e->getMessage()];
        }
    }
    
    // Buscar razas guardadas
    public static function buscar($raza = '', $solo_favoritos = false) {
        try {
            $sql = "SELECT * FROM api_perros WHERE situacion = 1";
            $params = [];
            
            if (!empty($raza)) {
                $sql .= " AND LOWER(per_raza) LIKE :raza";
                $params[':raza'] = "%" . strtolower($raza) . "%";
            }
            
            if ($solo_favoritos) {
                $sql .= " AND per_es_favorito = 1";
            }
            
            $sql .= " ORDER BY per_fecha_guardado DESC";
            
            $stmt = self::conectar()->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
            
        } catch (PDOException $e) {
            error_log('Error al buscar razas: ' . $e->getMessage());
            return [];
        }
    }
    
    // Buscar una raza por ID
    public static function buscarUno($id) {
        try {
            $sql = "SELECT * FROM api_perros WHERE per_id = ? AND situacion = 1";
            $stmt = self::conectar()->prepare($sql);
            $stmt->execute([$id]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log('Error al buscar raza por ID: ' . $e->getMessage());
            return false;
        }
    }
    
    // Actualizar favorito
    public static function toggleFavorito($id, $es_favorito) {
        try {
            $sql = "UPDATE api_perros SET per_es_favorito = ? WHERE per_id = ? AND situacion = 1";
            $stmt = self::conectar()->prepare($sql);
            $stmt->execute([$es_favorito, $id]);
            return true;
        } catch (PDOException $e) {
            error_log('Error al actualizar favorito: ' . $e->getMessage());
            return false;
        }
    }
    
    // Eliminar raza (soft delete)
    public static function eliminar($id) {
        try {
            $sql = "UPDATE api_perros SET situacion = 0 WHERE per_id = ?";
            $stmt = self::conectar()->prepare($sql);
            $stmt->execute([$id]);
            return true;
        } catch (PDOException $e) {
            error_log('Error al eliminar raza: ' . $e->getMessage());
            return false;
        }
    }
    
    // Obtener razas únicas
    public static function obtenerRazasUnicas() {
        try {
            $sql = "SELECT DISTINCT per_raza FROM api_perros 
                    WHERE situacion = 1 AND per_raza IS NOT NULL 
                    ORDER BY per_raza";
            $stmt = self::conectar()->prepare($sql);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_COLUMN);
        } catch (PDOException $e) {
            error_log('Error al obtener razas únicas: ' . $e->getMessage());
            return [];
        }
    }
    
    // Obtener favoritos
    public static function obtenerFavoritos() {
        try {
            $sql = "SELECT * FROM api_perros 
                    WHERE situacion = 1 AND per_es_favorito = 1 
                    ORDER BY per_raza";
            $stmt = self::conectar()->prepare($sql);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log('Error al obtener favoritos: ' . $e->getMessage());
            return [];
        }
    }
    
    // Actualizar imagen de raza
    public static function actualizarImagen($id, $nueva_imagen_url) {
        try {
            $sql = "UPDATE api_perros SET per_imagen_url = ? WHERE per_id = ? AND situacion = 1";
            $stmt = self::conectar()->prepare($sql);
            $stmt->execute([$nueva_imagen_url, $id]);
            return true;
        } catch (PDOException $e) {
            error_log('Error al actualizar imagen: ' . $e->getMessage());
            return false;
        }
    }
    
    // Contar razas por tipo
    public static function contarPorTipo() {
        try {
            $sql = "SELECT 
                    per_raza,
                    COUNT(*) as cantidad,
                    SUM(CASE WHEN per_es_favorito = 1 THEN 1 ELSE 0 END) as favoritos
                    FROM api_perros 
                    WHERE situacion = 1 
                    GROUP BY per_raza 
                    ORDER BY cantidad DESC";
            
            $stmt = self::conectar()->prepare($sql);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
            
        } catch (PDOException $e) {
            error_log('Error al contar por tipo: ' . $e->getMessage());
            return [];
        }
    }
}
?>