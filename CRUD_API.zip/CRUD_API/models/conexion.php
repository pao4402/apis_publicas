<?php

abstract class Conexion {  

    protected static $conexion; 

    public static function conectar() { 
        try { 
            self::$conexion = new PDO( 
                "informix:host=host.docker.internal; service=9088; database=techsolutions; server=informix; protocol=onsoctcp;",
                "informix", 
                "in4mix" 
            );
            self::$conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
          
            return self::$conexion;

        } catch (PDOException $e) {

            echo "Error de conexión: " . $e->getMessage();
            exit;
        }
    }
}


Conexion::conectar();
?>
