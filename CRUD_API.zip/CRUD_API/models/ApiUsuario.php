<?php
require_once 'conexion.php';

class ApiUsuario extends Conexion {
    
    // Guardar usuario de API
    public static function guardar($nombre, $username, $email, $telefono, $website, $compania) {
        try {
            // Verificar si ya existe
            $sqlCheck = "SELECT usu_id FROM api_usuarios WHERE usu_email = ?";
            $stmtCheck = self::conectar()->prepare($sqlCheck);
            $stmtCheck->execute([$email]);
            
            if ($stmtCheck->fetch()) {
                return ['success' => false, 'message' => 'El usuario ya existe'];
            }
            
            // Obtener fecha actual
            $fecha_actual = date('Y-m-d H:i:s');
            
            $sql = "INSERT INTO api_usuarios (usu_nombre, usu_username, usu_email, usu_telefono, usu_website, usu_compania, usu_fecha_guardado)
                    VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmt = self::conectar()->prepare($sql);
            $stmt->execute([$nombre, $username, $email, $telefono, $website, $compania, $fecha_actual]);
            
            return ['success' => true, 'message' => 'Usuario guardado correctamente'];
            
        } catch (PDOException $e) {
            error_log('Error al guardar usuario API: ' . $e->getMessage());
            return ['success' => false, 'message' => 'Error al guardar usuario: ' . $e->getMessage()];
        }
    }
    
    // Buscar usuarios guardados
    public static function buscar($termino = '') {
        try {
            $sql = "SELECT * FROM api_usuarios WHERE situacion = 1";
            $params = [];
            
            if (!empty($termino)) {
                $sql .= " AND (LOWER(usu_nombre) LIKE :termino OR LOWER(usu_email) LIKE :termino)";
                $params[':termino'] = "%" . strtolower($termino) . "%";
            }
            
            $sql .= " ORDER BY usu_fecha_guardado DESC";
            
            $stmt = self::conectar()->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
            
        } catch (PDOException $e) {
            error_log('Error al buscar usuarios API: ' . $e->getMessage());
            return [];
        }
    }
    
    // Buscar un usuario por ID
    public static function buscarUno($id) {
        try {
            $sql = "SELECT * FROM api_usuarios WHERE usu_id = ? AND situacion = 1";
            $stmt = self::conectar()->prepare($sql);
            $stmt->execute([$id]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log('Error al buscar usuario por ID: ' . $e->getMessage());
            return false;
        }
    }
    
    // Eliminar usuario (soft delete)
    public static function eliminar($id) {
        try {
            $sql = "UPDATE api_usuarios SET situacion = 0 WHERE usu_id = ?";
            $stmt = self::conectar()->prepare($sql);
            $stmt->execute([$id]);
            return true;
        } catch (PDOException $e) {
            error_log('Error al eliminar usuario API: ' . $e->getMessage());
            return false;
        }
    }
    
    // Actualizar usuario
    public static function actualizar($id, $nombre, $username, $email, $telefono, $website, $compania) {
        try {
            $sql = "UPDATE api_usuarios SET 
                    usu_nombre = ?, 
                    usu_username = ?, 
                    usu_email = ?, 
                    usu_telefono = ?, 
                    usu_website = ?, 
                    usu_compania = ?
                    WHERE usu_id = ? AND situacion = 1";
            
            $stmt = self::conectar()->prepare($sql);
            $stmt->execute([$nombre, $username, $email, $telefono, $website, $compania, $id]);
            return true;
            
        } catch (PDOException $e) {
            error_log('Error al actualizar usuario API: ' . $e->getMessage());
            return false;
        }
    }
    
    // Contar usuarios
    public static function contar() {
        try {
            $sql = "SELECT COUNT(*) as total FROM api_usuarios WHERE situacion = 1";
            $stmt = self::conectar()->prepare($sql);
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return $result['total'];
        } catch (PDOException $e) {
            error_log('Error al contar usuarios: ' . $e->getMessage());
            return 0;
        }
    }
}
?>