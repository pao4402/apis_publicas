<?php
require_once 'conexion.php';

class ApiRickMorty extends Conexion {
    
    // Guardar personaje
    public static function guardar($character_id, $nombre, $status, $especie, $genero, $origen, $ubicacion, $imagen_url) {
        try {
            // Verificar si ya existe
            $sqlCheck = "SELECT rick_id FROM api_rickmorty WHERE rick_character_id = ?";
            $stmtCheck = self::conectar()->prepare($sqlCheck);
            $stmtCheck->execute([$character_id]);
            
            if ($stmtCheck->fetch()) {
                return ['success' => false, 'message' => 'El personaje ya existe'];
            }
            
            // Obtener fecha actual
            $fecha_actual = date('Y-m-d H:i:s');
            
            $sql = "INSERT INTO api_rickmorty (rick_character_id, rick_nombre, rick_status, rick_especie, rick_genero, rick_origen, rick_ubicacion, rick_imagen_url, rick_fecha_guardado)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = self::conectar()->prepare($sql);
            $stmt->execute([$character_id, $nombre, $status, $especie, $genero, $origen, $ubicacion, $imagen_url, $fecha_actual]);
            
            return ['success' => true, 'message' => 'Personaje guardado correctamente'];
            
        } catch (PDOException $e) {
            error_log('Error al guardar personaje: ' . $e->getMessage());
            return ['success' => false, 'message' => 'Error al guardar personaje: ' . $e->getMessage()];
        }
    }
    
    // Buscar personajes guardados
    public static function buscar($nombre = '', $status = '') {
        try {
            $sql = "SELECT * FROM api_rickmorty WHERE situacion = 1";
            $params = [];
            
            if (!empty($nombre)) {
                $sql .= " AND LOWER(rick_nombre) LIKE :nombre";
                $params[':nombre'] = "%" . strtolower($nombre) . "%";
            }
            
            if (!empty($status)) {
                $sql .= " AND rick_status = :status";
                $params[':status'] = $status;
            }
            
            $sql .= " ORDER BY rick_fecha_guardado DESC";
            
            $stmt = self::conectar()->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
            
        } catch (PDOException $e) {
            error_log('Error al buscar personajes: ' . $e->getMessage());
            return [];
        }
    }
    
    // Buscar un personaje por ID
    public static function buscarUno($id) {
        try {
            $sql = "SELECT * FROM api_rickmorty WHERE rick_id = ? AND situacion = 1";
            $stmt = self::conectar()->prepare($sql);
            $stmt->execute([$id]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log('Error al buscar personaje por ID: ' . $e->getMessage());
            return false;
        }
    }
    
    // Eliminar personaje (soft delete)
    public static function eliminar($id) {
        try {
            $sql = "UPDATE api_rickmorty SET situacion = 0 WHERE rick_id = ?";
            $stmt = self::conectar()->prepare($sql);
            $stmt->execute([$id]);
            return true;
        } catch (PDOException $e) {
            error_log('Error al eliminar personaje: ' . $e->getMessage());
            return false;
        }
    }
    
    // Obtener estados únicos
    public static function obtenerEstados() {
        try {
            $sql = "SELECT DISTINCT rick_status FROM api_rickmorty 
                    WHERE situacion = 1 AND rick_status IS NOT NULL 
                    ORDER BY rick_status";
            $stmt = self::conectar()->prepare($sql);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_COLUMN);
        } catch (PDOException $e) {
            error_log('Error al obtener estados: ' . $e->getMessage());
            return [];
        }
    }
    
    // Obtener especies únicas
    public static function obtenerEspecies() {
        try {
            $sql = "SELECT DISTINCT rick_especie FROM api_rickmorty 
                    WHERE situacion = 1 AND rick_especie IS NOT NULL 
                    ORDER BY rick_especie";
            $stmt = self::conectar()->prepare($sql);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_COLUMN);
        } catch (PDOException $e) {
            error_log('Error al obtener especies: ' . $e->getMessage());
            return [];
        }
    }
    
    // Actualizar personaje
    public static function actualizar($id, $nombre, $status, $especie, $genero, $origen, $ubicacion) {
        try {
            $sql = "UPDATE api_rickmorty SET 
                    rick_nombre = ?, 
                    rick_status = ?, 
                    rick_especie = ?, 
                    rick_genero = ?, 
                    rick_origen = ?, 
                    rick_ubicacion = ?
                    WHERE rick_id = ? AND situacion = 1";
            
            $stmt = self::conectar()->prepare($sql);
            $stmt->execute([$nombre, $status, $especie, $genero, $origen, $ubicacion, $id]);
            return true;
            
        } catch (PDOException $e) {
            error_log('Error al actualizar personaje: ' . $e->getMessage());
            return false;
        }
    }
    
    // Estadísticas de personajes
    public static function obtenerEstadisticas() {
        try {
            $sql = "SELECT 
                    COUNT(*) as total_personajes,
                    COUNT(DISTINCT rick_especie) as total_especies,
                    COUNT(DISTINCT rick_origen) as total_origenes,
                    COUNT(CASE WHEN rick_status = 'Alive' THEN 1 END) as vivos,
                    COUNT(CASE WHEN rick_status = 'Dead' THEN 1 END) as muertos,
                    COUNT(CASE WHEN rick_status = 'unknown' THEN 1 END) as desconocidos
                    FROM api_rickmorty WHERE situacion = 1";
            
            $stmt = self::conectar()->prepare($sql);
            $stmt->execute();
            return $stmt->fetch(PDO::FETCH_ASSOC);
            
        } catch (PDOException $e) {
            error_log('Error al obtener estadísticas: ' . $e->getMessage());
            return [];
        }
    }
}
?>