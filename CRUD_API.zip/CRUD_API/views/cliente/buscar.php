<?php
// buscar.php para Cliente
include_once '../templates/header.php';
include_once '../templates/navbar.php';
require_once '../../models/Cliente.php';

$mensaje = $_GET['mensaje'] ?? '';

$nombre1 = $_GET['nombre1'] ?? '';
$nombre2 = $_GET['nombre2'] ?? '';
$apellido1 = $_GET['apellido1'] ?? '';
$apellido2 = $_GET['apellido2'] ?? '';
$empresa = $_GET['empresa'] ?? '';
$nit = $_GET['nit'] ?? '';
$telefono = $_GET['telefono'] ?? '';
$correo = $_GET['correo'] ?? '';
$direccion = $_GET['direccion'] ?? '';

$clientes = Cliente::buscar($nombre1, $nombre2, $apellido1, $apellido2, $empresa, $nit, $telefono, $correo, $direccion);
?>

<div class="container mt-5">

    <?php if ($mensaje == 'guardado') : ?>
        <div class="alert alert-success text-center">
            ¡Cliente guardado exitosamente!
        </div>
    <?php elseif ($mensaje == 'modificado') : ?>
        <div class="alert alert-info text-center">
            ¡Cliente modificado exitosamente!
        </div>
    <?php elseif ($mensaje == 'eliminado') : ?>
        <div class="alert alert-warning text-center">
            ¡Cliente eliminado exitosamente!
        </div>
    <?php endif; ?>

    <h2 class="text-center mb-4 text-white">Buscar Clientes</h2>

    <form method="get" class="p-4 rounded shadow bg-light">
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label class="form-label">Primer Nombre:</label>
                    <input type="text" name="nombre1" class="form-control" placeholder="Juan" value="<?= htmlspecialchars($nombre1) ?>">
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                    <label class="form-label">Segundo Nombre:</label>
                    <input type="text" name="nombre2" class="form-control" placeholder="Pedro" value="<?= htmlspecialchars($nombre2) ?>">
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label class="form-label">Primer Apellido:</label>
                    <input type="text" name="apellido1" class="form-control" placeholder="Rivas" value="<?= htmlspecialchars($apellido1) ?>">
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                    <label class="form-label">Segundo Apellido:</label>
                    <input type="text" name="apellido2" class="form-control" placeholder="Lopez" value="<?= htmlspecialchars($apellido2) ?>">
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label class="form-label">Empresa:</label>
                    <input type="text" name="empresa" class="form-control" placeholder="Propimob" value="<?= htmlspecialchars($empresa) ?>">
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                    <label class="form-label">NIT:</label>
                    <input type="number" name="nit" class="form-control" placeholder="95214591" value="<?= htmlspecialchars($nit) ?>">
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-4">
                <div class="mb-3">
                    <label class="form-label">Teléfono:</label>
                    <input type="number" name="telefono" class="form-control" placeholder="5555 5555" value="<?= htmlspecialchars($telefono) ?>">
                </div>
            </div>
            <div class="col-md-4">
                <div class="mb-3">
                    <label class="form-label">Correo Electrónico:</label>
                    <input type="email" name="correo" class="form-control" placeholder="nombre@empresa.com" value="<?= htmlspecialchars($correo) ?>">
                </div>
            </div>
            <div class="col-md-4">
                <div class="mb-3">
                    <label class="form-label">Dirección:</label>
                    <input type="text" name="direccion" class="form-control" placeholder="Zona 1" value="<?= htmlspecialchars($direccion) ?>">
                </div>
            </div>
        </div>

        <button type="submit" class="btn btn-info w-100 text-white">Buscar</button>
    </form>

    <div class="mt-4">
        <a href="crear.php" class="btn btn-success mb-3">Nuevo Cliente</a>
        <table class="table table-bordered table-hover">
            <thead class="table-dark">
                <tr>
                    <th>#</th>
                    <th>Nombre</th>
                    <th>Apellido</th>
                    <th>Empresa</th>
                    <th>NIT</th>
                    <th>Teléfono</th>
                    <th>Correo</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($clientes) > 0): ?>
                    <?php foreach ($clientes as $cliente): ?>
                        <tr>
                            <td><?= $cliente['CLI_ID'] ?></td>
                            <td><?= $cliente['CLI_NOMBRE1'] . ' ' . $cliente['CLI_NOMBRE2'] ?></td>
                            <td><?= $cliente['CLI_APE1'] . ' ' . $cliente['CLI_APE2'] ?></td>
                            <td><?= $cliente['CLI_EMPRESA'] ?></td>
                            <td><?= $cliente['CLI_NIT'] ?></td>
                            <td><?= $cliente['CLI_TELEFONO'] ?></td>
                            <td><?= $cliente['CLI_CORREO'] ?></td>
                            <td>
                                <a href="modificar.php?id=<?= $cliente['CLI_ID'] ?>" class="btn btn-warning btn-sm">Modificar</a>
                                <a href="../../controllers/cliente/eliminar.php?id=<?= $cliente['CLI_ID'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Está seguro de eliminar este cliente?')">Eliminar</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="8" class="text-center">No hay clientes encontrados.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include_once '../templates/footer.php'; ?>