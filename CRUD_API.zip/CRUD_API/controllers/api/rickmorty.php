<?php
header('Content-Type: application/json');

require_once '../../models/ApiRickMorty.php';

$action = $_GET['action'] ?? '';

try {
    switch($action) {
        case 'guardar':
            // Obtener datos del POST
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('Método no permitido');
            }
            
            $data = json_decode(file_get_contents('php://input'), true);
            
            // Validar datos requeridos
            if (empty($data['character_id']) || empty($data['name']) || empty($data['status'])) {
                throw new Exception('Datos incompletos');
            }
            
            $result = ApiRickMorty::guardar(
                $data['character_id'],
                $data['name'],
                $data['status'],
                $data['species'] ?? 'Unknown',
                $data['gender'] ?? 'unknown',
                $data['origin'] ?? 'Unknown',
                $data['location'] ?? 'Unknown',
                $data['image_url'] ?? ''
            );
            
            echo json_encode($result);
            break;
            
        case 'buscar':
            $nombre = $_GET['nombre'] ?? '';
            $estado = $_GET['estado'] ?? '';
            
            $personajes = ApiRickMorty::buscar($nombre, $estado);
            echo json_encode([
                'exito' => true, 
                'datos' => $personajes,
                'cantidad' => count($personajes)
            ]);
            break;
            
        case 'obtener':
            // Obtener un personaje específico por ID
            $id = $_GET['id'] ?? 0;
            
            if (!$id) {
                throw new Exception('ID no proporcionado');
            }
            
            $personajes = ApiRickMorty::buscar();
            $personaje = null;
            
            foreach ($personajes as $p) {
                if ($p['RICK_ID'] == $id) {
                    $personaje = $p;
                    break;
                }
            }
            
            if (!$personaje) {
                throw new Exception('Personaje no encontrado');
            }
            
            echo json_encode([
                'exito' => true,
                'datos' => $personaje
            ]);
            break;
            
        case 'eliminar':
            $id = $_GET['id'] ?? 0;
            
            if (!$id) {
                throw new Exception('ID no proporcionado');
            }
            
            $result = ApiRickMorty::eliminar($id);
            echo json_encode([
                'exito' => $result,
                'mensaje' => $result ? 'Personaje eliminado correctamente' : 'Error al eliminar personaje'
            ]);
            break;
            
        case 'estados':
            // Obtener lista de estados únicos
            $personajes = ApiRickMorty::buscar();
            $estados = array_unique(array_column($personajes, 'RICK_STATUS'));
            sort($estados);
            
            echo json_encode([
                'exito' => true,
                'datos' => array_values($estados)
            ]);
            break;
            
        case 'especies':
            // Obtener lista de especies únicas
            $personajes = ApiRickMorty::buscar();
            $especies = array_unique(array_column($personajes, 'RICK_ESPECIE'));
            sort($especies);
            
            echo json_encode([
                'exito' => true,
                'datos' => array_values($especies)
            ]);
            break;
            
        default:
            throw new Exception('Acción no válida');
    }
    
} catch (Exception $e) {
    echo json_encode([
        'exito' => false,
        'mensaje' => $e->getMessage()
    ]);
}
?>