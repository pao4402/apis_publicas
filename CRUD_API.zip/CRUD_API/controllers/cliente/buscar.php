<?php

require_once '../../models/cliente.php';

if (
    isset($_POST['nombre1']) &&
    isset($_POST['nombre2']) &&
    isset($_POST['apellido1'])&&
    isset($_POST['apellido2'])&&
    isset($_POST['empresa'])&&
    isset($_POST['nit'])&&
    isset($_POST['telefono'])&&
    isset($_POST['correo'])&&
    isset($_POST['direccion'])
) {
    $id = $_POST['id'];
    $nombre1 = htmlspecialchars(trim($_POST['nombre1']));
    $nombre2 = htmlspecialchars(trim($_POST['nombre2']));
    $apellido1 = htmlspecialchars(trim($_POST['apellido1']));
    $apellido2 = htmlspecialchars(trim($_POST['apellido2']));
    $empresa = htmlspecialchars(trim($_POST['empresa']));
    $nit = htmlspecialchars(trim($_POST['nit']));
    $telefono = htmlspecialchars(trim($_POST['telefono']));
    $correo = htmlspecialchars(trim($_POST['correo']));
    $direccion = htmlspecialchars(trim($_POST['direccion']));

    Cliente::modificar($id, $nombre1, $nombre2, $apellido1, $apellido2, $empresa, $nit, $telefono, $correo, $direccion);

    header('Location: ../../views/cliente/buscar.php?mensaje=modificado');
    exit;
} else {
    echo "Datos incompletos para modificar.";
}
?>