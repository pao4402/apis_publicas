<?php
require_once '../../models/ApiPais.php';

// Verificar si se reciben todos los datos necesarios
if (
    !empty($_POST['nombre']) &&
    !empty($_POST['nombre_oficial']) &&
    !empty($_POST['region'])
) {
    // Sanitizar los datos recibidos
    $nombre = htmlspecialchars(trim($_POST['nombre']));
    $nombre_oficial = htmlspecialchars(trim($_POST['nombre_oficial']));
    $capital = htmlspecialchars(trim($_POST['capital'] ?? ''));
    $region = htmlspecialchars(trim($_POST['region']));
    $poblacion = filter_var($_POST['poblacion'] ?? 0, FILTER_VALIDATE_INT) ?: 0;
    $area = filter_var($_POST['area'] ?? 0, FILTER_VALIDATE_FLOAT) ?: 0;
    $bandera_url = filter_var($_POST['bandera_url'] ?? '', FILTER_VALIDATE_URL) ?: '';
    
    try {
        // Intentar guardar el país
        $resultado = ApiPais::guardar(
            $nombre,
            $nombre_oficial,
            $capital,
            $region,
            $poblacion,
            $area,
            $bandera_url
        );
        
        if ($resultado['success']) {
            header('Location: ../../views/api/paises.php?mensaje=guardado');
        } else {
            header('Location: ../../views/api/paises.php?error=' . urlencode($resultado['message']));
        }
        exit;
        
    } catch (Exception $e) {
        echo "❌ Error al guardar: " . $e->getMessage();
    }
} else {
    echo "❌ Faltan datos obligatorios.";
}
?>