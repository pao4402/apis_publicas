create database techsolutions;


CREATE TABLE cliente  ( 
	cli_id     	SERIAL PRIMARY KEY, -------nombres
	cli_nombre1	VARCHAR(100) NOT NULL,
	cli_nombre2	VARCHAR(100),
	cli_ape1   	VARCHAR(100) NOT NULL, ----apellidos
	cli_ape2   	VARCHAR(100),
	cli_empresa	VARCHAR(100), -----empresa
	cli_nit   	INTEGER,-----nit
	cli_telefono  	INTEGER NOT NULL, ------telefono
	cli_correo   	VARCHAR(100) NOT NULL, -----correo
	cli_direccion   VARCHAR(100) NOT NULL, -----direcion
	situacion  	SMALLINT DEFAULT 1 -------situacion
	);


-- Tabla para usuarios (JSONPlaceholder)
CREATE TABLE IF NOT EXISTS api_usuarios (
    usu_id SERIAL PRIMARY KEY,
    usu_nombre VARCHAR(100),
    usu_username VARCHAR(50),
    usu_email VARCHAR(100),
    usu_telefono VARCHAR(20),
    usu_website VARCHAR(100),
    usu_compania VARCHAR(100),
    usu_fecha_guardado DATETIME YEAR TO SECOND,
    situacion SMALLINT DEFAULT 1
);

-- Tabla para países (REST Countries)
CREATE TABLE IF NOT EXISTS api_paises (
    pai_id SERIAL PRIMARY KEY,
    pai_nombre VARCHAR(100),
    pai_nombre_oficial VARCHAR(150),
    pai_capital VARCHAR(100),
    pai_region VARCHAR(50),
    pai_poblacion INTEGER,
    pai_area DECIMAL(10,2),
    pai_bandera_url VARCHAR(255),
    pai_fecha_guardado DATETIME YEAR TO SECOND,
    situacion SMALLINT DEFAULT 1
);

-- Tabla para personajes Rick & Morty
CREATE TABLE IF NOT EXISTS api_rickmorty (
    rick_id SERIAL PRIMARY KEY,
    rick_character_id INTEGER,
    rick_nombre VARCHAR(100),
    rick_status VARCHAR(20),
    rick_especie VARCHAR(50),
    rick_genero VARCHAR(20),
    rick_origen VARCHAR(100),
    rick_ubicacion VARCHAR(100),
    rick_imagen_url VARCHAR(255),
    rick_fecha_guardado DATETIME YEAR TO SECOND,
    situacion SMALLINT DEFAULT 1
);

-- Tabla para razas de perros
CREATE TABLE IF NOT EXISTS api_perros (
    per_id SERIAL PRIMARY KEY,
    per_raza VARCHAR(100),
    per_imagen_url VARCHAR(255),
    per_es_favorito SMALLINT DEFAULT 0,
    per_fecha_guardado DATETIME YEAR TO SECOND,
    situacion SMALLINT DEFAULT 1
);

-- Tabla para historial de búsquedas
CREATE TABLE IF NOT EXISTS api_historial (
    his_id SERIAL PRIMARY KEY,
    his_api_nombre VARCHAR(50),
    his_termino_busqueda VARCHAR(200),
    his_resultados INTEGER,
    his_fecha_busqueda DATETIME YEAR TO SECOND,
    situacion SMALLINT DEFAULT 1
);
